package com.thought_elevator.assignmentthree;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Instance variables
    private Button bakeButton, grandmaButton, feedGrandmaButton;
    private TextView cookieView, grandmaView;
    private int numberOfCookies;
    private int numberOfGrandmas;

    private void updateCookieCount() {
        cookieView.setText("Number of Cookies: " + numberOfCookies);
    }

    private class BakeButtonListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            numberOfCookies = numberOfGrandmas + (numberOfCookies + 1);
            updateCookieCount();
        }//onClick
    }//class BakeButtonListener

    private class FeedGrandmaButtonListener implements View.OnClickListener{
        @Override
        public void onClick(View view){
            if(numberOfGrandmas == 0){
                Toast.makeText(MainActivity.this, "You have no grandmas to feed!", Toast.LENGTH_LONG).show();
            }else{
                int cookiesToBeDeleted = numberOfGrandmas * 2;
                if(numberOfCookies < cookiesToBeDeleted){
                    Toast.makeText(MainActivity.this, "Bake more cookies first!", Toast.LENGTH_LONG).show();
                }else{
                    numberOfCookies = numberOfCookies - cookiesToBeDeleted;
                    updateCookieCount();
                }
            }
        }//onClick
    }//class FeedGrandmaButtonListener

    //onCreate func: Called when the activity is starting
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        /*When we override a method, we have the option of completely
        replacing the method in our class, or of extending the existing
        parent class' method. By calling super.onCreate(savedInstanceState);,
        you tell the Dalvik VM to run your code in addition to the existing code
        in the onCreate() of the parent class. If you leave out this line, then
        only your code is run. The existing code is ignored completely.*/
        super.onCreate(savedInstanceState);
        /*in Android the visual design is created in xml . And each Activity is associated to a design
        R means Resource
        layout means design
        main is the xml you have created under res->layout->main.xml*/
        setContentView(R.layout.activity_main);

        this.numberOfCookies = 0;
        this.numberOfGrandmas = 0;

        //Look for a child view with the given id. If this view has the given id, return this view.
        //then cast the view as a button
        this.bakeButton = (Button) findViewById(R.id.bake_button);
        //setOnClickListener() is a listener that can be used mostly with all kinds of view(widgets) for performing action on click
        this.bakeButton.setOnClickListener(new BakeButtonListener());

        feedGrandmaButton = (Button) findViewById(R.id.feed_grandma_button);
        feedGrandmaButton.setOnClickListener(new FeedGrandmaButtonListener());

        this.grandmaButton = (Button) findViewById(R.id.grandma_button);
        this.grandmaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                numberOfGrandmas++;
                grandmaView.setText("You have " + numberOfGrandmas + " grandmas!");
                numberOfCookies++;
                updateCookieCount();
            }//onClick
        });//setOnClickListener

        this.cookieView = (TextView) findViewById(R.id.cookie_label);
        this.grandmaView = (TextView) findViewById(R.id.grandma_label);
    }//onCreate
}//MainActivity